package com.dia.app.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.dia.app.dto.PredictionHistoryDTO;
import com.dia.app.dto.PredictionRequestDTO;
import com.dia.app.dto.PredictionResponseDTO;
import com.dia.app.entity.Prediction;
import com.dia.app.entity.User;
import com.dia.app.repository.PredictionRepository;
import com.dia.app.service.PredictionService;
import com.dia.app.service.PythonService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PredictionServiceImpl implements PredictionService {

    @Autowired
    private PythonService pythonService;

    @Autowired
    private PredictionRepository predictionRepository;

    @Override
    public PredictionResponseDTO predictAndGenerateDiet(
            PredictionRequestDTO request,
            User user
    ) {

        Map<String, Object> response = pythonService.predict(request);

        // ✅ Minimal required validation
        if (response == null ||
                !response.containsKey("prediction") ||
                !response.containsKey("diet_plan")) {

            throw new RuntimeException("Invalid Python response: " + response);
        }

        Integer predictionValue = (Integer) response.get("prediction");

        @SuppressWarnings("unchecked")
        Map<String, Object> dietPlan =
                (Map<String, Object>) response.get("diet_plan");

        String message = null;
        if (response.containsKey("why_this_result")) {
            message = String.valueOf(response.get("why_this_result"));
        }

        // ✅ Save to DB
        Prediction prediction = new Prediction();
        prediction.setResult(String.valueOf(predictionValue));
        prediction.setWhy_this_result(message);
        prediction.setDietPlan(dietPlan.toString());
        prediction.setUser(user);
        prediction.setCreatedAt(LocalDateTime.now());
        predictionRepository.save(prediction);

        // ✅ Send response to frontend
        PredictionResponseDTO dto = new PredictionResponseDTO();
        dto.setPrediction(predictionValue);
        dto.setMessage(message);
        dto.setDiet_plan(dietPlan);

        return dto;
    }



    @Override
    public Prediction getPrediction(Long id) {
        return predictionRepository.findById(id).orElse(null);
    }

    @Override
    public List<PredictionHistoryDTO> getPredictionHistory(Long userId) {
        return predictionRepository.findHistoryByUserId(userId);
    }
}
