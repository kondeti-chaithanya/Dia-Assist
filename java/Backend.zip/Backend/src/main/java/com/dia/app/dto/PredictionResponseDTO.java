package com.dia.app.dto;

import lombok.Data;
import java.util.Map;

@Data
public class PredictionResponseDTO {

    private Integer prediction;
    private String message;
    private Map<String, Object> diet_plan;
    private String why_this_result;
}
