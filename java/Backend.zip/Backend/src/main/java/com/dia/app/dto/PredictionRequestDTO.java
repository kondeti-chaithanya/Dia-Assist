package com.dia.app.dto;

import lombok.Data;

@Data
public class PredictionRequestDTO {
    private String gender;
    private Integer age;
    private Integer hypertension;
    private Integer heart_disease;
    private String smoking_history;
    private Double bmi;
    private Double HbA1c_level;
    private Integer blood_glucose_level;
}
