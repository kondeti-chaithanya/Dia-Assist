package com.dia.app.dto;

import lombok.Data;

@Data
public class UserRequestDTO {
	
	private String name;
	private String email;
	private String password;

}
